import Profile from "./Profile";
import ProfileInfo from "./ProfileInfo";
import FaqAccordion from "../Qoutes";
const General = () => {
  return (
    <div>
      <Profile />
      <ProfileInfo />
      <FaqAccordion />
    </div>
  );
};

export default General;
