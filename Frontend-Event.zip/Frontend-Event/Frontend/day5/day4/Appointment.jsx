import * as React from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import "../assets/Css/Appointment.css"; // Importing the CSS file
import img3 from "../assets/images/r.jpg";

const style = {
  position: "absolute",
  top: "40%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
  color: "black",
};

const BasicModal = () => {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here
  };

  return (
    <div>
      <Button onClick={handleOpen}>Book now</Button>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style} className="modal-content">
          <span className="close" onClick={handleClose}>
            &times;
          </span>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            Event Booking Form
          </Typography>
          <Typography id="modal-modal-description" sx={{ mt: 2 }}>
            Please fill out the details below to book the event.
          </Typography>
          <form onSubmit={handleSubmit} className="form-container">
            <div>
              <label htmlFor="name">Name:</label>
              <input type="text" id="name" name="name" required />
            </div>
            <div>
              <label htmlFor="email">Email:</label>
              <input type="email" id="email" name="email" required />
            </div>
            <div>
              <label htmlFor="phone">Phone:</label>
              <input type="tel" id="phone" name="phone" required />
            </div>
            <div>
              <label htmlFor="date">Date:</label>
              <input type="date" id="date" name="date" required />
            </div>
            {/* <div>
              <label htmlFor="comments">Comments:</label>
              <textarea id="comments" name="comments" rows="4" />
            </div> */}
            <Button type="submit">Submit</Button>
          </form>
        </Box>
      </Modal>
    </div>
  );
};

const Appointment = () => {
  return (
    <div className="appointments-container">
      <div className="text-section">
        <h2>Easy Appointments for You & Your Clients</h2>
        <p>
          One time or recurring events are being set up by people, companies or
          organisations for various gatherings all over the world all the time.
          In many of these cases, the event is limited by the number of
          participants that can participate and in such case it is important
          that people reserve their place. Very often, the organizer may also
          want to accept payments from the participants and then, an online
          appointment scheduler can be very useful, because people can pay at
          the same time they make a booking.
        </p>
        <p>
          The <strong>SimplyBook.me</strong> booking system is extremely
          flexible and allows event organizers to create a booking website,
          where clients and participants can come and reserve their places. They
          can also pay and give more information about themselves during the
          booking process. It is also very simple to set up multiple or
          recurring events.
        </p>
      </div>
      <div className="image-section">
        <img src={img3} alt="Event Booking Website" />
        <button className="book-now-btn">
          <BasicModal />
        </button>
      </div>
    </div>
  );
};

export default Appointment;
