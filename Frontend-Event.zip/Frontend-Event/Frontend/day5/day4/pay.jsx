import { useState } from "react";
import "../assets/Css/pay.css";

const Pay = () => {
  const [amount, setAmount] = useState(0);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (amount > 10) {
      const options = {
        key: "rzp_test_5H6wU9HYPhQs0K",
        key_secret: "woDlBcWB6OvCDTifjsxQsARC",
        amount: amount * 100,
        currency: "INR",
        name: "PLAY PALOOZA",
        handler: (res) => {
          alert(res.razorpay_payment_id);
        },
        prefill: {
          name: "PlayPalooza",
          email: "PlayPalooza@gmail.com",
          contact: "9361868683",
        },
        notes: {
          address: " office",
        },
        theme: {
          color: "#f5f5f7",
        },
      };
      const pay = new window.Razorpay(options);
      pay.open();
    } else {
      alert(
        "It is an Invalid amount!!. Please enter an amount greater than 1000"
      );
    }
  };

  return (
    <div className="payment-container">
      <h1 className="payment-header">Payment Page</h1>
      <form onSubmit={handleSubmit}>
        <label className="amount-label">Amount:</label>
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(Number(e.target.value))}
          className="amount-input"
        />
        <button type="submit" className="pay-button">
          Pay Now
        </button>
      </form>
    </div>
  );
};

export default Pay;
