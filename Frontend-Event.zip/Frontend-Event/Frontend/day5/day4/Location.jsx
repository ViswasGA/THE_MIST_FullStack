import { FaHome } from "react-icons/fa";
import "../assets/Css/Location.css";
const LocationCard = ({ city, addresses }) => (
  <div className="location-card">
    <FaHome className="location-icon" />
    <h3>{city}</h3>
    {addresses.map((address, index) => (
      <p key={index}>{address}</p>
    ))}
  </div>
);

const Locations = () => {
  const locations = [
    {
      city: "KOCHI",
      addresses: [
        "V8, 3rd Floor, JC Chambers, Panampilly Nagar, Ernakulam, Cochin - 682036",
        "4A, Regal Valencia, Elevakkatu Nagar, Cochin - 68202",
      ],
    },
    {
      city: "CHENNAI",
      addresses: [
        "35, Anna Salai, Little Mount, Next to Little Mount Metro Station, Nandanam, Chennai - 600015",
      ],
    },
    {
      city: "BANGALORE",
      addresses: ["5th Main Road, HSR Layout, Bangalore - 560102"],
    },
  ];

  return (
    <div className="locations-container">
      <h1>OFFICE LOCATIONS</h1>
      <div className="locations">
        {locations.map((location, index) => (
          <LocationCard
            key={index}
            city={location.city}
            addresses={location.addresses}
          />
        ))}
      </div>
    </div>
  );
};

export default Locations;
